Sean Sponsler

Python executable needs to be chmodded +x to run properly
Soft misses are not being registered properly as page faults